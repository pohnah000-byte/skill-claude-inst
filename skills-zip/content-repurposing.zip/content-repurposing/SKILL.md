---
name: content-repurposing
description: 'Переработка контента: превращает публичные видео, расшифровки, посты или разбор блогеров в новые материалы — посты для LinkedIn, треды для X, сценарии коротких видео, рассылки, планы статей, карусели и контент-планы. Используй, когда просят «переупакуй», «сделай посты из этого видео».'
license: MIT
metadata:
  version: 1.0.0
  author: ScrapeCreators
  homepage: https://scrapecreators.com
  repository: https://github.com/ScrapeCreators/social-media-research-skills
  requires-env: SCRAPECREATORS_API_KEY
  plugin: moi-navyki
---

# Content Repurposing

## Overview

Turn social research and transcripts into reusable content. This skill works best after `transcript-intelligence`, `outlier-post-finder`, or `creator-profile-teardown`, but it can also start directly from URLs.

## When to Use

Use this skill when the user asks to:

- turn videos or transcripts into posts
- repurpose TikToks, Reels, Shorts, podcasts, or webinars
- create LinkedIn posts, X threads, scripts, newsletters, or blog outlines
- build a content calendar from winning social ideas
- adapt a competitor/creator pattern without plagiarizing

## Workflow

1. Gather source material: URLs, transcripts, posts, or research report.
2. Extract content atoms: hooks, stories, claims, frameworks, examples, data points, CTAs.
3. Choose output formats and platform constraints.
4. Rewrite for the user's voice and audience.
5. Keep attribution/internal notes when ideas are inspired by a source.
6. Produce ready-to-use drafts plus optional variants.

## Output Format

```markdown
# Repurposed Content Pack

## Source Material
- [source](url)

## Content Atoms
| Atom | Source | Best format |
|---|---|---|

## LinkedIn Posts
1. ...

## X Threads
1. ...

## Short-Form Scripts
### Script 1
- Hook:
- Body:
- CTA:

## Newsletter / Blog Ideas
- ...
```

## Common Pitfalls

- Do not plagiarize. Adapt structure and insight, not unique wording unless quoting with attribution.
- Do not flatten every platform into the same format.
- Do not lose the original hook if it is the strongest part.
